---
name: Tracely Habit System
colors:
  surface: '#fbf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#fbf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f0'
  surface-container: '#efeeeb'
  surface-container-high: '#eae8e5'
  surface-container-highest: '#e4e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#50453e'
  inverse-surface: '#30312f'
  inverse-on-surface: '#f2f0ed'
  outline: '#82746d'
  outline-variant: '#d4c3ba'
  surface-tint: '#FFFBF5'
  primary: '#553722'
  on-primary: '#ffffff'
  primary-container: '#6f4e37'
  on-primary-container: '#eec1a4'
  inverse-primary: '#eabda0'
  secondary: '#934b1b'
  on-secondary: '#ffffff'
  secondary-container: '#ffa26b'
  on-secondary-container: '#783605'
  tertiary: '#2f4409'
  on-tertiary: '#ffffff'
  tertiary-container: '#455c20'
  on-tertiary-container: '#b8d48a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdcc6'
  primary-fixed-dim: '#eabda0'
  on-primary-fixed: '#2d1604'
  on-primary-fixed-variant: '#5f402a'
  secondary-fixed: '#ffdbc9'
  secondary-fixed-dim: '#ffb68d'
  on-secondary-fixed: '#331200'
  on-secondary-fixed-variant: '#753403'
  tertiary-fixed: '#d0eda0'
  tertiary-fixed-dim: '#b4d086'
  on-tertiary-fixed: '#121f00'
  on-tertiary-fixed-variant: '#374d12'
  background: '#fbf9f6'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2df'
  page-bg: '#FAF8F5'
  surface-card: '#FFFFFF'
  surface-recessed: '#F2EDE6'
  primary-coffee: '#6F4E37'
  accent-terracotta: '#C2703D'
  accent-text: '#9A4F24'
  text-primary: '#1F1A15'
  text-secondary: '#655A4E'
  text-disabled: '#9A8E83'
  border-hairline: '#E6DFD5'
  border-outline: '#9F8D7B'
  feedback-success: '#5A7233'
  feedback-error: '#9C4A32'
typography:
  display-hero:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  quote-body:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 28px
  section-header:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-default:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-secondary:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-label:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  caption-meta:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  overline:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
  micro-data:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system is built for a quiet, offline-first habit ritual. It draws philosophical and visual cues from Japanese stationery, linen-bound notebooks, and warm ceramic textures rather than digital gamification or aggressive dashboards. 

The emotional tone is calm, unhurried, and deeply grounding. By treating daily reflections and tracking as an analog-inspired pause, the interface relieves cognitive load and eliminates streak anxiety. Visual design operates under radical restraint: no vibrant neons, no glassmorphism, no jarring alert reds, and no decorative gradients.

Instead, tactile clarity is achieved through warm paper backdrops, tactile recessed fills, crisp hairline rules, and a single intentional accent per viewport. Layouts privilege breathing room and clear typographic rhythm over data density.

## Colors

The core color strategy prioritizes earthy warmth over artificial saturation. Surfaces are layered from the foundational warm bone paper tint (`#FAF8F5`) up to crisp raised white cards (`#FFFFFF`) or carved-in recessed fills (`#F2EDE6`).

Primary actions, key interactive toggles, and solid marks utilize the deep, authoritative coffee brown (`#6F4E37`). The secondary color, terracotta (`#C2703D`), is held under strict design governance: it must appear at most once per viewport for singular high-priority focal points or streak milestones. 

Functional states reject digital harshness: positive completion adopts an organic olive green (`#5A7233`), while warnings and errors use a muted brick earth tone (`#9C4A32`). High-saturation reds are prohibited. Structural division relies entirely on hairline parchment dividers (`#E6DFD5`) and tactile boundary outlines (`#9F8D7B`).

## Typography

Typography is set exclusively in **Inter** to ensure maximum legibility while maintaining a structured, architectural cadence. Optical hierarchy is built strictly through scale jumps and weight transitions between Regular (400) and Semibold (600).

Paragraph and body measures are restricted to a maximum width of 60 characters per line to emulate the comfortable column width of an open book. Subtitles, attributions, and timestamps preserve tonal quietness using secondary and disabled neutral shades rather than reducing font size excessively. Section overlines leverage a tracked-out letterspacing (`0.08em`) to demarcate sections cleanly without visual weight.

## Layout & Spacing

Layout geometry follows a rigorous 4px base increment across all form factors. Mobile surfaces are bound to a strict 20px (`1.25rem`) lateral margin, ensuring content recedes naturally from the device edges.

Component spacing adheres to dedicated structural intervals:
- **0.25rem (4px):** Micro pairings (labels to subtitles, indicator marks).
- **0.5rem (8px):** Compact element gaps (chip spacing, icon-to-text separation).
- **1rem (16px):** Primary component inner padding (card interiors, habit item insets).
- **1.5rem (24px):** Major block and section separation.
- **2rem (32px):** Viewport headers and terminal sheet footers.

Interactive touch targets maintain an unconditional minimum perimeter of 48x48dp, with primary form inputs and action bars normalized to fixed ergonomic heights (52px–56px) for effortless single-hand thumb reach.

## Elevation & Depth

Depth is established primarily via tonal stratification and paper-like physical layering rather than dramatic artificial shadow rigs. Neumorphism, blurs, and glassmorphic transparencies are forbidden.

1. **Base Ground:** The warm canvas (`#FAF8F5`) acts as the desktop or table surface.
2. **Carved Recesses:** Inputs, progress tracks, and inactive tiles sit at `#F2EDE6`, visually punched into the page without inner drop shadows.
3. **Floating Paper Sheets:** Raised cards (`#FFFFFF`) feature a single, featherweight ambient shadow: `0 2px 8px rgba(0, 0, 0, 0.05)`. This creates a tactile, 0.5mm paper lift effect.
4. **Modals & Drawers:** Bottom sheets overlay the base canvas supported by a quiet, warm dark scrim set strictly at `rgba(31, 26, 21, 0.35)`.
5. **Hairline Delimitation:** Surfaces of identical elevation are separated by crisp 1px `#E6DFD5` hairline rules.

## Shapes

The design system employs tailored, proportional radii to echo gently tumbled pebbles and smooth stationery corners. 

- **Containers & Sheet Modules:** 16px radius for primary task cards, stat summaries, and interactive containers; bottom sheet modals transition to 20px on top corners.
- **Interactive Controls:** 12px radius on text fields, action buttons, and input blocks.
- **Tags & Badges:** 8px radius for category chips and status indicators.
- **Checkboxes:** 4px radius for task check squares, preserving crisp alignment alongside typography.
- **Organic Nodes:** Fully circular (9999px) profiles are reserved for day toggles, habit completion rings, and the floating action trigger.

## Components

### Buttons
- **Primary Action:** Solid `#6F4E37` fill, `#FFFFFF` semibold text, 12px border radius, 52px fixed height. Touch state drops to 90% opacity without scale shifts. Disabled states render at 38% opacity.
- **Secondary / Tertiary Button:** Unfilled with 1px `#9F8D7B` outline, `#1F1A15` label, `#FAF8F5` surface touch response.

### Chips & Filters
- **Inactive Chip:** `#F2EDE6` recessed background, `#655A4E` label, 8px border radius, 8px vertical by 12px horizontal padding.
- **Active Chip:** `#FFFFFF` fill with a crisp 1px `#6F4E37` stroke and `#6F4E37` semibold text.

### Habit Items & Checkboxes
- **Circular Habit Toggle:** 28px diameter ring with 2px stroke in `#9F8D7B`. On completion, fills smoothly with `#5A7233` enclosing an embedded `#FFFFFF` checkmark.
- **Task Checkbox:** 20px rounded square (4px radius) with 2px `#9F8D7B` stroke. Checked state switches to `#5A7233` with completed body text fading to `#9A8E83` with strikethrough.

### Input Fields
- **Container:** 56px height, 12px radius, filled with `#F2EDE6` or `#FFFFFF`.
- **Borders:** 1px `#9F8D7B` at rest; transitions to 2px `#6F4E37` upon focus. Placeholder text strictly `#9A8E83`.

### Cards & Habit Containers
- Raised `#FFFFFF` backdrop with 16px radius, enclosed by a faint `#E6DFD5` 1px border and the signature soft shadow (`0 2px 8px rgba(0, 0, 0, 0.05)`). 
- Optional category accent: A 3px solid vertical bar pinned to the inner left edge denoting custom category color mappings.